﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Automation;
using System.Windows.Forms;
using Microsoft.Win32;

internal sealed class ClockIntegration : IDisposable {
 static string Link {get{return System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Startup),"Bảng điều khiển.lnk");}}
 static string LegacyLink {get{return System.IO.Path.Combine(System.IO.Path.GetDirectoryName(Link),"BangDieuKhien - Dong ho.lnk");}}
 const string runKey=@"Software\Microsoft\Windows\CurrentVersion\Run";
 const string appName="Bảng điều khiển";
 internal static bool Registered{get{using(var key=Registry.CurrentUser.OpenSubKey(runKey))return (key!=null&&key.GetValue(appName)!=null)||System.IO.File.Exists(Link)||System.IO.File.Exists(LegacyLink);}}
 internal static void SetRunEntry(RegistryKey key,string path,bool on){
  if(on)key.SetValue(appName,"\""+path+"\" --clock-tray",RegistryValueKind.String);
  else key.DeleteValue(appName,false);
 }
 internal static void Register(bool on){
  using(var key=Registry.CurrentUser.CreateSubKey(runKey))SetRunEntry(key,Application.ExecutablePath,on);
  System.IO.File.Delete(Link);System.IO.File.Delete(LegacyLink);
 } delegate IntPtr MouseProc(int code,IntPtr msg,IntPtr data);
 [DllImport("user32",SetLastError=true)]static extern IntPtr SetWindowsHookEx(int id,MouseProc callback,IntPtr module,uint thread);
 [DllImport("kernel32",CharSet=CharSet.Unicode)]static extern IntPtr GetModuleHandle(string name);
 [DllImport("user32")]static extern bool UnhookWindowsHookEx(IntPtr h);
 [DllImport("user32")]static extern IntPtr CallNextHookEx(IntPtr h,int code,IntPtr msg,IntPtr data);
 [DllImport("user32")]static extern IntPtr WindowFromPoint(Point point);
 [DllImport("user32")]static extern IntPtr GetAncestor(IntPtr window,uint flags);
 [DllImport("user32",CharSet=CharSet.Unicode)]static extern int GetClassName(IntPtr window,StringBuilder name,int size);
 static string Class(IntPtr h){var text=new StringBuilder(128);GetClassName(h,text,text.Capacity);return text.ToString();}
 readonly Form owner;readonly ContextMenuStrip menu=new ContextMenuStrip(); readonly MouseProc proc;

 bool disposed; IntPtr hook;
 internal ClockIntegration(Form owner,Action show,Action restartExplorer){
  this.owner=owner;proc=Mouse;
  menu.Items.Add("Tắt màn hình",null,(s,e)=>DisplayCurtain.ShowFor(owner));
  menu.Items.Add("Restart Explorer",null,(s,e)=>restartExplorer());
  menu.Items.Add("Task Manager",null,(s,e)=>Native.Open("taskmgr.exe"));
  menu.Items.Add("Taskbar settings",null,(s,e)=>Native.Open("ms-settings:taskbar"));
  menu.Items.Add(new ToolStripSeparator());
  menu.Items.Add("Bảng điều khiển",owner.Icon.ToBitmap(),(s,e)=>show());  hook=SetWindowsHookEx(14,proc,GetModuleHandle(null),0);
  if(hook==IntPtr.Zero)throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
 }

 static bool OnTaskbar(Point p){
  IntPtr h=WindowFromPoint(p);
  string root=Class(GetAncestor(h,2));
  return root=="Shell_TrayWnd"||root=="Shell_SecondaryTrayWnd";
 }
 [DllImport("user32",CharSet=CharSet.Unicode)]static extern IntPtr FindWindowEx(IntPtr parent,IntPtr after,string cls,string title);
 [DllImport("user32")]static extern uint GetWindowThreadProcessId(IntPtr window,out uint process);
 [DllImport("user32")]static extern bool IsWindowVisible(IntPtr window);
 [DllImport("user32")]static extern IntPtr SendMessageTimeout(IntPtr window,uint msg,IntPtr w,IntPtr l,uint flags,uint timeout,out IntPtr result);
 [DllImport("user32")]static extern int GetMenuItemCount(IntPtr menuHandle);
 [DllImport("user32",CharSet=CharSet.Unicode)]static extern int GetMenuString(IntPtr menuHandle,uint position,StringBuilder label,int capacity,uint flags);
 [DllImport("user32")]static extern bool PostMessage(IntPtr window,uint message,IntPtr w,IntPtr l);
 static bool IsTaskbarMenu(IntPtr popup){
  IntPtr handle;
  if(SendMessageTimeout(popup,0x1E1,IntPtr.Zero,IntPtr.Zero,2,50,out handle)==IntPtr.Zero || handle==IntPtr.Zero || GetMenuItemCount(handle)<2)return false;
  bool manager=false,settings=false;
  for(uint i=0;i<GetMenuItemCount(handle);i++){
   var text=new StringBuilder(160);GetMenuString(handle,i,text,text.Capacity,0x400);
   string label=text.ToString().Replace("&","").Trim().ToLowerInvariant();
   manager|=label=="task manager" || label=="trình quản lý tác vụ";
   settings|=label=="taskbar settings" || label=="cài đặt thanh tác vụ";
  }
  return manager && settings;
 }
 [DllImport("user32")]static extern IntPtr GetForegroundWindow();
 static bool ModernMenu(IntPtr window,Point click,uint shellPid){
  try{
   var root=AutomationElement.FromHandle(window);
   var items=root.FindAll(TreeScope.Descendants,new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.MenuItem));
   bool manager=false,settings=false;
   foreach(AutomationElement item in items){
    var c=item.Current;
    if(c.IsOffscreen || c.ProcessId!=shellPid)continue;
    var rect=c.BoundingRectangle;
    if(rect.IsEmpty || click.X<rect.Left-32 || click.X>rect.Right+32 || click.Y<rect.Top-200 || click.Y>rect.Bottom+200)continue;
    string label=c.Name.Replace("&","").Trim().ToLowerInvariant();
    if(label=="task manager"||label=="trình quản lý tác vụ")manager=true;
    else if(label=="taskbar settings"||label=="cài đặt thanh tác vụ")settings=true;
    else return false;
   }
   return manager && settings;
  }catch(Exception){return false;}
 }
 int sequence;
 async void ObserveMenu(Point p,uint shellPid,int ticket){
  for(int i=0;i<30;i++){
   await System.Threading.Tasks.Task.Delay(25);
   if(disposed || ticket!=sequence || Math.Abs(Cursor.Position.X-p.X)>5 || Math.Abs(Cursor.Position.Y-p.Y)>5)return;
   if(i%3==1){
    IntPtr foreground=GetForegroundWindow();
    uint foregroundPid;GetWindowThreadProcessId(foreground,out foregroundPid);
    if(foregroundPid==shellPid && foreground!=IntPtr.Zero){
     bool modern=await System.Threading.Tasks.Task.Run(()=>ModernMenu(foreground,p,shellPid));
     if(disposed || ticket!=sequence)return;
     if(modern && foreground==GetForegroundWindow()){
      SendKeys.SendWait("{ESC}");
      await System.Threading.Tasks.Task.Delay(80);
      if(!disposed && ticket==sequence && OnTaskbar(p))menu.Show(p);
      return;
     }
    }
   }
   IntPtr popup=IntPtr.Zero;
   while((popup=FindWindowEx(IntPtr.Zero,popup,"#32768",null))!=IntPtr.Zero){
    uint pid;
    if(!IsWindowVisible(popup)||GetWindowThreadProcessId(popup,out pid)==0 || pid!=shellPid||!IsTaskbarMenu(popup))continue;
    if(!PostMessage(popup,0x100,(IntPtr)27,IntPtr.Zero))return;
    for(int wait=0;wait<12 && IsWindowVisible(popup);wait++)await System.Threading.Tasks.Task.Delay(15);
    if(!disposed && ticket==sequence && !IsWindowVisible(popup) && Cursor.Position==p && OnTaskbar(p))menu.Show(p);
    return;
   }
  }
 }
 IntPtr Mouse(int code,IntPtr msg,IntPtr data){
  if(!disposed && code>=0 && (msg.ToInt32()==0x201 || msg.ToInt32()==0x204))sequence++;
  if(!disposed && code>=0 && msg.ToInt32()==0x205){
   var p=new Point(Marshal.ReadInt32(data),Marshal.ReadInt32(data,4));
   var root=GetAncestor(WindowFromPoint(p),2);string cls=Class(root);
   if(cls=="Shell_TrayWnd" || cls=="Shell_SecondaryTrayWnd"){
    uint pid;uint thread=GetWindowThreadProcessId(root,out pid);int ticket=sequence;
    owner.BeginInvoke((Action)(()=>ObserveMenu(p,pid,ticket)));
   }
  }
  return CallNextHookEx(hook,code,msg,data);
 }
 public void Dispose(){disposed=true;UnhookWindowsHookEx(hook);menu.Dispose();}
}

