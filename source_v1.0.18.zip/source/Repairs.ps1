﻿$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$inputValue = $env:BDK_INPUT
function Step($message){[Console]::WriteLine("@@"+$message)}
function Set-Number($path,$name,$value) {
    Step ("Áp dụng thiết lập "+$name); if (!(Test-Path -LiteralPath $path)) { New-Item -Path $path -Force | Out-Null }
    New-ItemProperty -LiteralPath $path -Name $name -PropertyType DWord -Value $value -Force | Out-Null
}
function With-ExplorerStopped([scriptblock]$action) {
    Step "Bước 1/3 • Dừng Explorer của phiên hiện tại"; $session = (Get-Process -Id $PID).SessionId
    Get-Process explorer -ErrorAction SilentlyContinue | Where-Object SessionId -eq $session | Stop-Process -Force
    try { & $action } finally { Step "Bước 3/3 • Mở lại Explorer"; Start-Process "$env:windir\explorer.exe" }
}
function With-SpoolerStopped([scriptblock]$action) {
    try { Step "Dừng dịch vụ in"; Stop-Service Spooler; & $action } finally { Step "Khởi động lại dịch vụ in"; Start-Service Spooler }
}
try {
 switch ($env:BDK_COMMAND) {
 {$_ -in "updateOff","updateOn"} {
    $off=$_ -eq "updateOff"
    $record="HKLM:\SOFTWARE\LeQuocViet\BangDieuKhien"
    $svcKey="HKLM:\SYSTEM\CurrentControlSet\Services\wuauserv"
    Step "10% • Đọc cấu hình Windows Update"
    $saved=(Get-ItemProperty -LiteralPath $record -Name UpdateSnapshot -ErrorAction SilentlyContinue).UpdateSnapshot
    if(!$saved -and !$off){throw "Chưa có cấu hình do công cụ lưu để khôi phục."}
    if(!$saved){
        $service=Get-Service wuauserv
        if($service.Status -notin "Running","Stopped"){throw "Dịch vụ đang chuyển trạng thái. Hãy thử lại."}
        $config=Get-ItemProperty -LiteralPath $svcKey
        $saved=@{start=[int]$config.Start;delay=$config.DelayedAutoStart;running=($service.Status -eq "Running")} | ConvertTo-Json -Compress
        if(!(Test-Path $record)){New-Item $record -Force | Out-Null}
        New-ItemProperty $record -Name UpdateSnapshot -Value $saved -PropertyType String -Force | Out-Null
    }
    $state=$saved | ConvertFrom-Json
    if($off){
        Step "40% • Tắt khởi động dịch vụ Windows Update"
        Set-Service wuauserv -StartupType Disabled
        Step "70% • Dừng Windows Update"
        Stop-Service wuauserv
        if((Get-Service wuauserv).Status -ne "Stopped" -or (Get-ItemProperty $svcKey).Start -ne 4){throw "Windows chưa áp dụng. Dùng Bật Update để khôi phục."}
        "100% • Đã dừng Windows Update."
    }else{
        Step "40% • Khôi phục kiểu khởi động Windows Update"
        $modes=@{2="Automatic";3="Manual";4="Disabled"}
        Set-Service wuauserv -StartupType $modes[[int]$state.start]
        if($null -ne $state.delay){Set-ItemProperty $svcKey DelayedAutoStart ([int]$state.delay)}
        elseif((Get-ItemProperty $svcKey).PSObject.Properties["DelayedAutoStart"]){Remove-ItemProperty $svcKey DelayedAutoStart}
        Step "75% • Khôi phục trạng thái dịch vụ"
        if($state.running){Start-Service wuauserv}else{Stop-Service wuauserv}
        if(((Get-Service wuauserv).Status -eq "Running") -ne $state.running -or (Get-ItemProperty $svcKey).Start -ne $state.start){throw "Chưa khôi phục đủ cấu hình. Có thể nhấn Bật Update để thử lại."}
        Remove-ItemProperty $record UpdateSnapshot
        "100% • Đã khôi phục Windows Update theo cấu hình ban đầu."
    }
 }
 'notifications' { Set-Number 'HKCU:\Software\Microsoft\Windows\CurrentVersion\PushNotifications' ToastEnabled 0; 'Đã tắt thông báo dạng biểu ngữ cho người dùng hiện tại.' }
 'firewallOn' { Set-NetFirewallProfile -Profile Domain,Private,Public -Enabled True; 'Đã bật tường lửa.' }
 'rename' {
    if ($inputValue -notmatch '^(?![0-9]+$)[a-z0-9](?:[a-z0-9-]{0,13}[a-z0-9])?$') { throw 'Tên máy cần 1–15 ký tự chữ, số hoặc dấu gạch nối.' }
    Step "50% • Áp dụng tên máy"; Rename-Computer -NewName $inputValue; 'Đã đổi tên máy. Khởi động lại để có hiệu lực.'
 }
 {$_ -in 'classic','modern'} {
    $key='HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32'
    if ($_ -eq 'classic') { (New-Item -Path $key -Force).SetValue('','') }
    elseif (Test-Path -LiteralPath $key) { Remove-Item -LiteralPath $key }
    With-ExplorerStopped {}; 'Đã áp dụng cấu hình menu cho Explorer.'
 }
 'taskmgr' { Set-Number 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\System' DisableTaskMgr 0; Step "80% • Mở Task Manager"; Start-Process taskmgr.exe; 'Đã mở Task Manager.' }
 'explorer' { With-ExplorerStopped {}; 'Đã khởi động lại Explorer.' }
 'icons' {
    With-ExplorerStopped {
        Step "50% • Xoá bộ nhớ đệm biểu tượng"; $cache=Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Explorer'
        Get-ChildItem -LiteralPath $cache -Filter 'iconcache*.db' -File -Force | Remove-Item -Force
        $old=Join-Path $env:LOCALAPPDATA 'IconCache.db'
        if(Test-Path -LiteralPath $old){Remove-Item -LiteralPath $old -Force}
    }; 'Explorer đã tạo lại bộ nhớ đệm biểu tượng.'
 }
 'usb' {
    Set-Number 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' NoDriveTypeAutoRun 255
    Step "20% • Tìm ổ USB"; $volumes=@([IO.DriveInfo]::GetDrives() | Where-Object {$_.DriveType -eq 'Removable' -and $_.IsReady})
     $index=0;foreach($v in $volumes){Step ("{0}% • Quét USB {1}" -f (20+[int](80*$index/$volumes.Count)),$v.Name);$index++;Start-MpScan -ScanType CustomScan -ScanPath $v.RootDirectory.FullName}
    "Đã tắt AutoPlay. Đã quét $($volumes.Count) ổ tháo rời bằng Microsoft Defender."
 }
 'queue' {
    With-SpoolerStopped {
        Step "50% • Xoá lệnh in đang chờ"; $queue=Join-Path ([Environment]::SystemDirectory) 'spool\PRINTERS'
        Get-ChildItem -LiteralPath $queue -File -Force | Remove-Item -Force
    }; 'Đã xoá lệnh in và bật lại Print Spooler.'
 }
 'canon' {
    $root='HKLM:\SYSTEM\CurrentControlSet\Control\Print'
    $model='^Canon\s+(?:LBP[ -]*)?2900(?:\b|$)'
    function CanonQueues { Get-Printer | Where-Object {$_.Name -match $model -or $_.DriverName -match $model} }
    Step 'Bước 1/4 • 0% • Kiểm tra khóa và hàng đợi Canon 2900'
    $before=@(CanonQueues)
    With-SpoolerStopped {
        $count=0
        foreach($key in Get-ChildItem -LiteralPath "$root\Printers" | Where-Object PSChildName -match $model){
            Remove-Item -LiteralPath $key.PSPath -Recurse -Force
            $count++
        }
        Step "Bước 1/4 • 25% • Đã xoá $count key Canon 2900"
        Step 'Bước 2/4 • 25% • Kiểm tra UsbPortList và Port'
        $count=0
        foreach($sub in 'UsbPortList','Port'){
            $path="$root\Monitors\USB Monitor\$sub"
            if(Test-Path -LiteralPath $path){Remove-Item -LiteralPath $path -Recurse -Force;$count++}
        }
        Step "Bước 2/4 • 50% • Đã xoá $count key USB Monitor"
    }
    Step 'Bước 3/4 • 50% • Gỡ các hàng đợi Canon 2900 còn lại'
    foreach($printer in @(CanonQueues)){Remove-Printer -InputObject $printer}
    $remaining=@(CanonQueues)
    $removed=@($before | Where-Object {$_.Name -notin $remaining.Name}).Count
    Step "Bước 3/4 • 75% • Đã xoá $removed máy in Canon 2900"
    if($remaining.Count){throw "Bước 3/4 • Còn $($remaining.Count) hàng đợi Canon 2900"}
    Step 'Bước 4/4 • 75% • Chờ xác nhận tắt và bật lại nguồn máy in'
    Step 'POWER'
    if([Console]::ReadLine() -ne 'YES'){'Đã dừng trước bước quét máy in.';break}
    Step 'Bước 4/4 • 80% • Quét lại thiết bị'
    & pnputil.exe /scan-devices | Out-Null
    if($LASTEXITCODE){throw "Bước 4/4 • Quét thiết bị thất bại ($LASTEXITCODE)"}
    for($i=0;$i -le 15;$i++){
        $found=@(CanonQueues).Count
        if($found -or $i -eq 15){break}
        Step "Bước 4/4 • $(80+$i)% • Chờ Windows nhận hàng đợi Canon 2900"
        Start-Sleep -Seconds 2
    }
    "Bước 4/4 • 100% • Đã tìm thấy $found máy in Canon 2900."
 }
 'lan' {
    if($inputValue -and $inputValue -notmatch '^[A-Za-z0-9](?:[A-Za-z0-9.-]{0,251}[A-Za-z0-9])?$'){throw 'Tên máy chủ hoặc địa chỉ IPv4 không hợp lệ.'}
    $credentialStatus='Chưa lưu Guest vì ô tên/IP máy chủ đang trống.'
    if($inputValue){
        Add-Type -TypeDefinition @"
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
public static class PrinterCredential {
 [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
 struct Entry {
  public uint Flags, Type;
  public string Target, Comment;
  public System.Runtime.InteropServices.ComTypes.FILETIME Updated;
  public uint Size;
  public IntPtr Secret;
  public uint Persist, Count;
  public IntPtr Attributes, Alias;
  public string User;
 }
 [DllImport("advapi32",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool CredRead(string target,uint type,uint flags,out IntPtr data);
 [DllImport("advapi32",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool CredWrite(ref Entry entry,uint flags);
 [DllImport("advapi32")] static extern void CredFree(IntPtr ptr);
 static bool Exists(string target){
  IntPtr ptr;
  if(!CredRead(target,2,0,out ptr)){
   int error=Marshal.GetLastWin32Error();
   if(error==1168)return false;
   throw new Win32Exception(error);
  }
  try{
   var entry=(Entry)Marshal.PtrToStructure(ptr,typeof(Entry));
   if(!String.Equals(entry.User,"Guest",StringComparison.OrdinalIgnoreCase)||entry.Size!=0)
    throw new InvalidOperationException("Máy chủ đã có credential khác. Đã giữ thông tin đăng nhập hiện có.");
   return true;
  }finally{CredFree(ptr);}
 }
 public static void Save(string target){
  if(Exists(target))return;
  var entry=new Entry{Target=target,Type=2,Persist=2,User="Guest"};
  if(!CredWrite(ref entry,0))throw new Win32Exception(Marshal.GetLastWin32Error());
  if(!Exists(target))throw new InvalidOperationException("Windows chưa xác nhận credential Guest.");
 }
}
"@
        try{[PrinterCredential]::Save($inputValue);$credentialStatus="Đã lưu Guest cho $inputValue (mật khẩu trống)."}
        catch{$credentialStatus="Guest: $($_.Exception.GetBaseException().Message)"}
        Step $credentialStatus
    }
    $manual=$false
    try{
    Step 'Bước 1/4 • Bật Network discovery và File and printer sharing'
    $fw=New-Object -ComObject HNetCfg.FwPolicy2
    foreach($group in '@FirewallAPI.dll,-32752','@FirewallAPI.dll,-28502'){
        foreach($profile in 1,2,4){
            $fw.EnableRuleGroup($profile,$group,$true)
            if(!$fw.IsRuleGroupEnabled($profile,$group)){throw "Chưa bật nhóm $group trên profile $profile"}
        }
    }
    Step 'Bước 2/4 • Bật chia sẻ thư mục Public'
    Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
[ComImport, Guid("B4CD448A-9C86-4466-9201-2E62105B87AE"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IDefaultSharing {
 void CreateShare(int folder,int role);
 void DeleteShare(int folder);
 [PreserveSig] int ShareExists(int folder);
 void GetSharePermissions(int folder,out int role);
}
public static class PublicSharing {
 public static void Enable(){
  var service=(IDefaultSharing)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("49F371E1-8C5C-4D9C-9A3B-54A6827F513C")));
  try{
   int role=0;
   if(service.ShareExists(2)==0)service.GetSharePermissions(2,out role);
   if(role!=2 && role!=3)service.CreateShare(2,2);
   service.GetSharePermissions(2,out role);
   if(role!=2 && role!=3)throw new InvalidOperationException("Public folder sharing: Windows did not confirm write access.");
  }finally{Marshal.ReleaseComObject(service);}
 }
}
"@
    [PublicSharing]::Enable()
    Step 'Bước 2/4 • 40% • Tự động tắt Password protected sharing'
    Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes
    Start-Process 'ms-settings:network-advancedsharing'
    $scope=[Windows.Automation.TreeScope]::Descendants
    $any=[Windows.Automation.Condition]::TrueCondition
    $changed=$false
    $applied=$false
    $opened=@{}
    for($attempt=0;$attempt -lt 30 -and !$applied;$attempt++){
        Start-Sleep -Milliseconds 300
        $windows=[Windows.Automation.AutomationElement]::RootElement.FindAll([Windows.Automation.TreeScope]::Children,$any)
        foreach($win in $windows){
            $app=Get-Process -Id $win.Current.ProcessId -ErrorAction SilentlyContinue
            if($app.ProcessName -notin 'SystemSettings','ApplicationFrameHost'){continue}
            foreach($el in $win.FindAll($scope,$any)){
                $id=$el.Current.AutomationId
                $name=$el.Current.Name
                $isPassword=$id -match 'PasswordProtectedSharing' -or $name -match '^(Password.protected sharing|Chia sẻ.*bảo vệ.*mật khẩu)'
                $isAll=$id -match 'AllNetworks' -or $name -match '^(All networks|Tất cả (các )?mạng)'
                if(!$isPassword -and !$isAll){continue}
                $node=$el
                for($level=0;$level -lt 4 -and $node;$level++){
                    $pattern=$null
                    if($isPassword -and $node.TryGetCurrentPattern([Windows.Automation.TogglePattern]::Pattern,[ref]$pattern)){
                        if($pattern.Current.ToggleState -eq 'Off'){$applied=$true}
                        elseif(!$changed -and $node.Current.IsEnabled){$pattern.Toggle();$changed=$true}
                        break
                    }
                    if($isAll -and $node.TryGetCurrentPattern([Windows.Automation.ExpandCollapsePattern]::Pattern,[ref]$pattern)){
                        if($pattern.Current.ExpandCollapseState -eq 'Collapsed'){$pattern.Expand()}
                        break
                    }
                    if($isAll -and $node.Current.ControlType -eq [Windows.Automation.ControlType]::Button -and !$opened.Count -and $attempt -gt 2 -and $node.TryGetCurrentPattern([Windows.Automation.InvokePattern]::Pattern,[ref]$pattern)){
                        $pattern.Invoke();$opened.done=$true;break
                    }
                    $node=[Windows.Automation.TreeWalker]::RawViewWalker.GetParent($node)
                }
                if($applied){break}
            }
            if($applied){break}
        }
    }
    if(!$applied){throw 'Đã bật chia sẻ. Windows chưa xác nhận Password protected sharing ở trạng thái Off.'}
    Step 'Bước 2/4 • Đã xác nhận Password protected sharing: Off'
    }catch{
        $manual=$true
        Step "Chuyển sang hướng dẫn thủ công • $($_.Exception.Message)"
        try{Start-Process 'ms-settings:network-advancedsharing'}catch{}
        [Console]::WriteLine('@@SHAREHELP')
        if([Console]::ReadLine() -ne 'OK'){"Đã dừng. $credentialStatus";break}
    }
    if($inputValue){
        Step "Bước 3/4 • 60% • Kiểm tra SMB đến $inputValue"
        if(!(Test-NetConnection $inputValue -Port 445 -InformationLevel Quiet -WarningAction SilentlyContinue)){throw "Đã cấu hình chia sẻ trên máy này. Không kết nối được TCP 445 đến $inputValue"}
    }
    foreach($service in 'FDResPub','fdPHost'){
        Step "Bước 4/4 • 75% • Khởi động $service"
        Set-Service $service -StartupType Automatic
        Start-Service $service
        Step "Bước 4/4 • $service • $((Get-Service $service).Status)"
    }
    Step 'Bước 4/4 • 90% • Bật trang quét mạng trong Add Printer'
    $wizard='HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\Wizard'
    if(!(Test-Path $wizard)){New-Item -Path $wizard -Force | Out-Null}
    foreach($name in 'DomainDisplayPrinters_State','NonDomainDisplayPrinters_State'){
        New-ItemProperty -LiteralPath $wizard -Name $name -PropertyType DWord -Value 1 -Force | Out-Null
    }
    if($inputValue){Start-Process explorer.exe -ArgumentList ("\\$inputValue")}
    if($manual){"Đã hoàn tất các bước dịch vụ. Cài đặt chia sẻ do người dùng xác nhận. $credentialStatus"}else{"Đã áp dụng cấu hình chia sẻ. $credentialStatus"}
 }
 'temp' {
    Step "10% • Kiểm tra thư mục Temp"; $folder=(Get-Item -LiteralPath ([IO.Path]::GetTempPath())).FullName.TrimEnd('\')
    $expected=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'Temp'
    if($folder -ne $expected -or ((Get-Item -LiteralPath $folder).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'TEMP nằm ngoài thư mục Temp chuẩn của người dùng.'}
    $count=0;$skip=0
    $dirs=New-Object 'System.Collections.Generic.Stack[string]';$dirs.Push($folder)
    $empty=New-Object 'System.Collections.Generic.Stack[string]'
    Step "30% • Dọn các tệp tạm"; while($dirs.Count){
        $dir=$dirs.Pop()
        foreach($entry in Get-ChildItem -LiteralPath $dir -Force -ErrorAction SilentlyContinue){
            if($entry.Attributes -band [IO.FileAttributes]::ReparsePoint){$skip++;continue}
            if($entry.PSIsContainer){$dirs.Push($entry.FullName);$empty.Push($entry.FullName);continue}
            try{[IO.File]::Delete($entry.FullName);$count++}catch{$skip++}
        }
    }
    Step "90% • Dọn thư mục rỗng"; while($empty.Count){try{[IO.Directory]::Delete($empty.Pop(),$false)}catch{}}
    "Đã xoá $count tệp tạm. Bỏ qua $skip mục bị khoá hoặc liên kết."
 }
 default {throw 'Tác vụ không hợp lệ.'}
 }
} catch { [Console]::WriteLine($_.Exception.Message);exit 1 }





